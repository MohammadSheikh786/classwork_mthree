

package com.sg.dvdlibrary.dao;




import com.sg.dvdlibrary.dto.DVDLibraryException;
import com.sg.dvdlibrary.dto.DVD;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class DVDLibraryDaoFileImpl implements DVDLibraryDao {

    public static final String DVD_LIBRARY_FILE = "dvd_library_file.txt";
    public static final String DELIMITER = "::";

    private Map<String, DVD> dvds = new HashMap<>();

    @Override
    public DVD addDVD(String title, DVD dvd) throws DVDLibraryException {
        DVD newDVD = dvds.put(title, dvd);
        writeDVD();
        return newDVD;
    }

    @Override
    public List<DVD> getAllDVDs() throws DVDLibraryException {
        loadDVDs();
        return new ArrayList<DVD>(dvds.values());
    }

    @Override
    public DVD getDVD(String title) throws DVDLibraryException {
        loadDVDs();
        return dvds.get(title);
    }

    @Override
    public DVD removeDVD(String title) throws DVDLibraryException {
        DVD removedDVD = dvds.remove(title);
        writeDVD();
        return removedDVD;
    }

    private void loadDVDs() throws DVDLibraryException {
        Scanner scanner;

        try {
            // Create Scanner for reading the file
            scanner = new Scanner(new BufferedReader(new FileReader(DVD_LIBRARY_FILE)));
        } catch (FileNotFoundException e) {
            throw new DVDLibraryException(
                    " Could not load DVD Library data into memory.", e);
        }
        // currentLine holds the most recent line read from the file
        String currentLine;
        // currentTokens holds each of the parts of the currentLine after it has
        // been split on our DELIMITER
        // we use :: as our delimiter.
        
       
      
        String[] currentTokens;
     
        // Process while we have more lines in the file
        while (scanner.hasNextLine()) {
            // get the next line in the file
            currentLine = scanner.nextLine();
            // break up the line into tokens
            currentTokens = currentLine.split(DELIMITER);
            // Create a new DVD object 
            
            
            // pass the DVD title into the DVD constructor
            DVD currentDVD = new DVD(currentTokens[0]);
            // Set the remaining vlaues on currentDVD
            currentDVD.setReleaseDate(currentTokens[1]);
            currentDVD.setRating(currentTokens[2]);
            currentDVD.setDirector(currentTokens[3]);
            currentDVD.setStudio(currentTokens[4]);
            currentDVD.setRating(currentTokens[5]);

            // Put currentDVD into the map using title as the key
            dvds.put(currentDVD.getTitle(), currentDVD);
        }
        // close scanner
        scanner.close();
    }

    private void writeDVD() throws DVDLibraryException {
       
        PrintWriter out;

        try {
            out = new PrintWriter(new FileWriter((DVD_LIBRARY_FILE), false));
        } catch (IOException e) {
            throw new DVDLibraryException(
                    "Could not save DVD data.", e);
        }

        List<DVD> DVDList = this.getAllDVDs();
        for (DVD currentDVD : DVDList) {
            
            out.println(currentDVD.getTitle() + DELIMITER
                    + currentDVD.getReleaseDate() + DELIMITER
                    + currentDVD.getRating() + DELIMITER
                    + currentDVD.getDirector() + DELIMITER
                    + currentDVD.getStudio() + DELIMITER
                    + currentDVD.getComment());
            // force PrintWriter to write line to the file
            out.flush();
        }
        // Clean up
        out.close();
    }

}
