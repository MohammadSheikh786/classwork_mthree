
package com.sg.dvdlibrary.dao;

import com.sg.dvdlibrary.dto.DVDLibraryException;
import com.sg.dvdlibrary.dto.DVD;
import java.util.List;

public interface DVDLibraryDao {

    DVD addDVD(String DVD, DVD dvd) throws DVDLibraryException;

    List<DVD> getAllDVDs() throws DVDLibraryException;

    DVD getDVD(String dvdTitle) throws DVDLibraryException;

    DVD removeDVD(String dvdTitle) throws DVDLibraryException;
}
