/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.dvdlibrary.dto;

/**
 *
 * @author 13439
 */
public class DVDLibraryException extends Exception {

    public DVDLibraryException(String message) {
        super(message);
    }

    public DVDLibraryException(String message, Throwable cause) {
        super(message, cause);
    }
}
