import com.sg.dvdlibrary.dao.DVDLibraryDao;
import com.sg.dvdlibrary.dao.DVDLibraryDaoFileImpl;
import com.sg.dvdlibrary.dto.DVD;

import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNull;


public class DVDLibraryDaoTest {

    private final DVDLibraryDao dao = new DVDLibraryDaoFileImpl();

    public DVDLibraryDaoTest() {
    }

    //@After
    public static void tearDownClass() {
    }

    //@Before
    public void setUp() throws Exception { // going to run before all test methods for this class
        
        List<DVD> DVDList = dao.getAllDVDs();
        for (DVD dvd : DVDList) {
            dao.removeDVD(dvd.getTitle());
        }
    }

    //@After
    public void tearDown() {
    }

    //@Test
    public void testAddDVD() throws Exception {
        DVD dvd = new DVD("Test");
        dvd.setReleaseDate("2000");
        dvd.setRating("G");
        dvd.setDirector("Mohammad");
        dvd.setStudio("Sony");
        dvd.setComment("Fake DVD");

        dao.addDVD(dvd.getTitle(), dvd);

        DVD fromDao = dao.getDVD(dvd.getTitle());

 //       assertEquals(dvd, fromDao);
    }
//    }
//
//    /**
//     * Test of addStudent method, of class DVDLibraryDao.
//     */
//    @Test
//    public void testAddStudent() throws Exception {
//
//    }

//    /**
//     * Test of getAllDVDs method, of class DVDLibraryDao.
//     */
   // @Test
    public void testGetAllDVDs() throws Exception {
        DVD dvd1 = new DVD("Test1");
        dvd1.setReleaseDate("2001");
        dvd1.setRating("G");
        dvd1.setDirector("Jack");
        dvd1.setStudio("Disney");
        dvd1.setComment("Fake DVD");

        dao.addDVD(dvd1.getTitle(), dvd1);

        DVD dvd2 = new DVD("Test2");
        dvd2.setReleaseDate("2002");
        dvd2.setRating("G");
        dvd2.setDirector("Bob");
        dvd2.setStudio("Disney");
        dvd2.setComment("Fake DVD 2");

        dao.addDVD(dvd2.getTitle(), dvd2);

     //   assertEquals(2, dao.getAllDVDs().size());

    }

    //@Test
    public void testRemoveDVD() throws Exception {
            DVD dvd1 = new DVD("Test1");
        dvd1.setReleaseDate("2001");
        dvd1.setRating("G");
        dvd1.setDirector("Jack");
        dvd1.setStudio("Disney");
        dvd1.setComment("Fake DVD");

        dao.addDVD(dvd1.getTitle(), dvd1);

         DVD dvd2 = new DVD("Test2");
        dvd2.setReleaseDate("2002");
        dvd2.setRating("G");
        dvd2.setDirector("Bob");
        dvd2.setStudio("Disney");
        dvd2.setComment("Fake DVD 2");


        dao.addDVD(dvd2.getTitle(), dvd2);

        dao.removeDVD(dvd1.getTitle());
        assertEquals(1, dao.getAllDVDs().size());
        assertNull(dao.getDVD(dvd1.getTitle()));

        dao.removeDVD(dvd2.getTitle());
       assertEquals(0, dao.getAllDVDs().size());
        assertNull(dao.getDVD(dvd2.getTitle()));

    }

   
}
