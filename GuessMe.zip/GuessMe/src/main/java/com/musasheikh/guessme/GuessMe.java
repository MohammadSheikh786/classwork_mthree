/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.musasheikh.guessme;

/**
 *
 * @author 13439
 */

import java.util.Scanner;

public class GuessMe {
    public static void main(String[] args) {
       
       int secretNum; 
       int guess;
       boolean correct = false;
       
       Scanner keyboard = new Scanner(System.in);
       
       System.out.println("Give me you secret number: ");
       secretNum = keyboard.nextInt();
       
       System.out.println("I've chosen a number. Betcha can't guess it! ");
       
       
       while (!correct){
           System.out.println(" Your guess: ");
           guess = keyboard.nextInt();
          
           if (guess == secretNum){
               correct = true;
               System.out.println("Wow, nice guess! That was it!");
           }
           else if (guess < secretNum){
               System.out.println("Ha, nice try - too low! I chose" + secretNum);
             
           }
           else if (guess < secretNum){
               System.out.println("Too bad, way too high. I chose" + secretNum);
       }
       }
    }
}


              
       
      